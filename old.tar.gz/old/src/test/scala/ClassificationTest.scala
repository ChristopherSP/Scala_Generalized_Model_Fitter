import org.scalatest._
class ClassificationTest extends FlatSpec {
  "Teste 1" should "exit TRUE" in {
    val a = 1
    val b = 1
    assert(a === b)
  }
}
